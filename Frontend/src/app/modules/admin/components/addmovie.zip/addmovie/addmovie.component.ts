import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { v4 as uuidv4 } from 'uuid';

import { Movie } from 'src/app/models/Movie';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.css']
})
export class AddmovieComponent implements OnInit {

  moviePicture: string | ArrayBuffer | null = null;

  movieForm!: FormGroup;


  ngOnInit(): void {
 
    this.movieForm = new FormGroup({
      movieId: new FormControl(uuidv4(), [Validators.required]),
      movieName: new FormControl('', [Validators.required]),
      cast: new FormControl(''),
      directorName: new FormControl('', [Validators.required]),
      releaseDate: new FormControl('', [Validators.required]),
      synopsis: new FormControl('', [Validators.required]),
      moviePicture: new FormControl(null)
        
      })
  }

  onSubmit() {
    console.log("this.movieForm", this.movieForm)
  }

  onFileSelected(event: Event)
  {
    const inp = event.target;
    console.log("inp",inp)
  }

}
// export interface Movie {
//   movieId: string;
//   movieName: string;
//   cast: string[];
//   directorName: string;
//   releaseDate: Date;
//   synopsis: string;
//   moviePicture?: string | ArrayBuffer | null;
//   reviews: Review[];
// }
